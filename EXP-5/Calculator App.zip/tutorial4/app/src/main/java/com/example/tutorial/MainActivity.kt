package com.example.tutorial

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.tutorial.ui.theme.TutorialTheme
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main);
        val textView = findViewById<TextView>(R.id.calculatorTextView)

        val btn7 = findViewById<Button>(R.id.btn7)
        val btn8 = findViewById<Button>(R.id.btn8)
        val btn9 = findViewById<Button>(R.id.btn9)
        val btnDivide = findViewById<Button>(R.id.btnDivide)
        val btn4 = findViewById<Button>(R.id.btn4)
        val btn5 = findViewById<Button>(R.id.btn5)
        val btn6 = findViewById<Button>(R.id.btn6)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btn1 = findViewById<Button>(R.id.btn1)
        val btn2 = findViewById<Button>(R.id.btn2)
        val btn3 = findViewById<Button>(R.id.btn3)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btn0 = findViewById<Button>(R.id.btn0)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnEquals = findViewById<Button>(R.id.btnEquals)
        val btnClear = findViewById<Button>(R.id.btnClear)

        btn7.setOnClickListener { textView.text = textView.text.toString() + "7" }
        btn8.setOnClickListener { textView.text = textView.text.toString() + "8" }
        btn9.setOnClickListener { textView.text = textView.text.toString() + "9" }
        btnDivide.setOnClickListener { textView.text = textView.text.toString() + "/" }
        btn4.setOnClickListener { textView.text = textView.text.toString() + "4" }
        btn5.setOnClickListener { textView.text = textView.text.toString() + "5" }
        btn6.setOnClickListener { textView.text = textView.text.toString() + "6" }
        btnMultiply.setOnClickListener { textView.text = textView.text.toString() + "*" }
        btn1.setOnClickListener { textView.text = textView.text.toString() + "1" }
        btn2.setOnClickListener { textView.text = textView.text.toString() + "2" }
        btn3.setOnClickListener { textView.text = textView.text.toString() + "3" }
        btnSubtract.setOnClickListener { textView.text = textView.text.toString() + "-" }
        btn0.setOnClickListener { textView.text = textView.text.toString() + "0" }
        btnAdd.setOnClickListener { textView.text = textView.text.toString() + "+" }
        btnClear.setOnClickListener{textView.text = ""}
        btnEquals.setOnClickListener {
            try {
                val expression = ExpressionBuilder(textView.text.toString()).build()
                val result = expression.evaluate()
                val longResult = result.toLong()
                if (result == longResult.toDouble()) {
                    textView.text = longResult.toString()
                } else {
                    textView.text = result.toString()
                }
            } catch (e: Exception) {
                textView.text = "Error"
            }
        }
    }
}
