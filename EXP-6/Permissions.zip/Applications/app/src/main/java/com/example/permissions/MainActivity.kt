package com.example.permissions

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.*
import android.provider.DocumentsContract


class MainActivity : AppCompatActivity() {

    private val fileName = "song.fm.mp3"
    private val filePickerRequest = 1001
    private val folderPickerRequest = 1002

    private lateinit var pickFileButton: Button
    private lateinit var pickFolderButton: Button

    private var selectedFileUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pickFileButton = findViewById(R.id.writeToFileButton)
        pickFolderButton = findViewById(R.id.copyFileButton)

        pickFileButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, filePickerRequest)
        }

        pickFolderButton.setOnClickListener {
            if (selectedFileUri == null) {
                Toast.makeText(this, "Select file first", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                startActivityForResult(intent, folderPickerRequest)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK && data != null) {
            when (requestCode) {
                filePickerRequest -> {
                    selectedFileUri = data.data
                    Toast.makeText(this, "File selected", Toast.LENGTH_SHORT).show()
                }

                folderPickerRequest -> {
                    val folderUri = data.data
                    if (folderUri != null && selectedFileUri != null) {
                        copyFileToFolder(selectedFileUri!!, folderUri)
                    }
                }
            }
        }
    }

    private fun copyFileToFolder(sourceUri: Uri, destFolderUri: Uri) {
        try {
            val fileName = "song.fm.mp3"

            // Grant write permission for the folder
            contentResolver.takePersistableUriPermission(
                destFolderUri,
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
            )

            // Create new document in destination folder
            val docUri = Uri.parse("$destFolderUri/document/${destFolderUri.lastPathSegment}%2F$fileName")
            val createFileUri = DocumentsContract.createDocument(
                contentResolver,
                destFolderUri,
                "audio/mpeg",
                fileName
            )

            if (createFileUri != null) {
                val inputStream = contentResolver.openInputStream(sourceUri)
                val outputStream = contentResolver.openOutputStream(createFileUri)

                inputStream?.copyTo(outputStream!!)
                inputStream?.close()
                outputStream?.close()

                Toast.makeText(this, "File copied to SD Card Downloads!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Failed to create file in destination folder", Toast.LENGTH_SHORT).show()
            }

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Copy failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
